﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MustDo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Factorial(3));
            Console.WriteLine(Fibonacci(10));
            Console.WriteLine(Pow(-2,-3));
            Console.WriteLine(13 * 17);
            Console.WriteLine(IsPrime(221));
            Console.Read();
        }

        public static uint Factorial(uint n)
        {
            uint res = 1;
            for (uint i = 1; i < n + 1; i++)
            {
                res *= i;
            }
            return res;
        }

        public static uint Fibonacci (uint n)
        {
            if (n == 0)
            {
                return 0;
            }
            else if (n == 1)
            {
                return 1;
            }
            else
            {
                return Fibonacci(n - 1) + Fibonacci(n - 2);
            }
        }

        public static double Pow(int x, int n)
        {
            double res = 1;
            if (n == 0)
            {
                return res;
            }
            else if (n < 0)
            {
                for (int i = 0; i > n; i--)
                {
                    res /= x;
                }
            }
            else
            {
                for (int i = 0; i < n; i++)
                {
                    res *= x;
                }
            }
            return res;
        }

        public static bool IsPrime(uint n)
        {
            if (n < 4)
            {
                return true;
            }
            else
            {
                bool ans = true;
                double racine = Math.Sqrt(n);
                for (int i = 2; i <= racine; i++)
                {
                    if (n % i == 0)
                    {
                        ans = false;
                        Console.WriteLine(i);
                    }
                }
                return ans;
            }
        }
    }
}
