﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarresMagiques
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(IsMagic(GenerateMagicSquare(5)));
            Console.Read();
        }

        public static bool GoodLength(int[,] mat)
        {
            return mat.GetLength(0) == mat.GetLength(1);
        }

        public static int Sum(int[] array)
        {
            int res = 0;
            for (int i = 0; i < array.Length; i++)
            {
                res += array[i];
            }
            return res;
        }

        public static int[] GetRow(int[,] mat, int n)
        {
            int lon = mat.GetLength(0);
            int[] row = new int[lon];
            for (int i = 0; i < lon; i++)
            {
                row[i] = mat[n, i];
            }
            return row;
        }

        public static int[] GetColumn(int[,] mat, int n)
        {
            int lon = mat.GetLength(0);
            int[] row = new int[lon];
            for (int i = 0; i < lon; i++)
            {
                row[i] = mat[i, n];
            }
            return row;
        }

        public static bool IsMagic(int[,] mat)
        {
            int lon = mat.GetLength(0);
            int i = 0;
            int j = 0;
            int res1 = 0;
            int res2 = 0;
            for (i = 0; i < lon; i++)
            {
                res1 += mat[i, j];
                j++;
            }
            j = 0;
            for (i = lon - 1; i >= 0; i--)
            {
                res2 += mat[i, j];
                j++;
            }

            if (res1 == res2)
            {
                i = 0;
                while (i < lon && Sum(GetRow(mat, i)) == Sum(GetColumn(mat, i)))
                {
                    i++;
                    return true;
                }
            }
            return false;
        }

        public static int[,] GenerateMagicSquare(int len)
        {
            int[,] mat = new int[len, len];
            for (int i = 0; i < len; i++)
            {
                for (int j = 0; j < len; j++)
                {
                    mat[i, j] = -1;
                }
            }

            int lenCarre = len * len; 
            int a = len - 1;
            int b = len / 2;
            mat[a, b] = 1;
            int num = 2;

            while (mat[(a + 1) % len, (b + 1) % len] == -1 || mat[(a + len - 1) % len, b] == -1)
            {
                if (mat[(a + 1) % len, (b + 1) % len] != -1 || (a == len - 1) && (b == len - 1))
                {
                    a = (a + len - 1) % len;
                }
                else
                {
                    a = (a + 1) % len;
                    b = (b + 1) % len;
                }
                mat[a, b] = num;
                num++;
            }
            return mat;
        }
    }
}
