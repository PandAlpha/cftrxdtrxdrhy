﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindromes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(NoSpaces("bon     jour t        oi  "));
            Console.WriteLine(ToLowerCase("BoNJouR > .Toi[ ; ZorQA "));
            Console.WriteLine(IsPalindrome("]][Rions noir[]]"));
            Console.WriteLine(GeneratePalindrome(7));
            Console.WriteLine(IsPalindrome(GeneratePalindrome(0)));
            Console.Read();
        }

        public static string NoSpaces (string str)
        {
            string str2 = "";
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] != ' ')
                {
                    str2 += str[i];
                }
            }
            return str2;
        }

        public static string ToLowerCase(string str)
        {
            string str2 = "";
            for (int i = 0; i < str.Length; i++)
            {
                int ascii = Convert.ToInt16(str[i]);
                if (ascii > 64 && ascii < 91)
                {
                    str2 += Convert.ToChar(ascii + 32);
                }
                else
                {
                    str2 += str[i];
                }
            }
            return str2;
        }

        public static bool IsPalindrome(string str)
        {
            str = ToLowerCase(NoSpaces(str));
            int lon = str.Length / 2;
            int i = 0;
            while (i < lon && str[i] == str[str.Length - i - 1])
            {
                i++;
            }
            return i == lon;
        }

        public static string GeneratePalindrome(uint len)
        {
            Random rand = new Random();

            string str = "";
            string str2 = "";
            uint lon = len / 2;
            for (int i = 0; i < lon; i++)
            {
                char random_character = (char)(rand.Next(97, 123));
                str += random_character;
                str2 = random_character + str2;
            }
            if (len % 2 != 0)
            {
                str += (char)(rand.Next(97, 123));
            }

            return str + str2;
        }
    }
}
